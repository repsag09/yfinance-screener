"""
Flask Stock Screener – Railway-ready
"""

import logging
import os
from datetime import datetime, timedelta

from flask import Flask, jsonify, render_template, request

from screener import scan_market

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)

# Simple in-memory cache so we don't hammer Yahoo on every page load
_CACHE: dict = {"data": None, "expires": datetime.min}


def get_cached_scan(force: bool = False, max_candidates: int = 100) -> dict:
    now = datetime.utcnow()
    if not force and _CACHE["data"] is not None and now < _CACHE["expires"]:
        return _CACHE["data"]
    logger.info("Running fresh market scan…")
    data = scan_market(max_candidates=max_candidates)
    _CACHE["data"] = data
    _CACHE["expires"] = now + timedelta(minutes=8)  # cache ~8 min
    return data


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/scan")
def api_scan():
    force = request.args.get("force", "0") == "1"
    try:
        size = min(int(request.args.get("size", 100)), 200)
    except ValueError:
        size = 100
    data = get_cached_scan(force=force, max_candidates=size)
    return jsonify(data)


@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "time": datetime.utcnow().isoformat() + "Z"})


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
