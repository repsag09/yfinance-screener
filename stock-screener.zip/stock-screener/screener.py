"""
U.S. Micro-Cap Momentum Stock Screener
Uses Yahoo Finance via yfinance for screening + deep analysis.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Any

import numpy as np
import pandas as pd
import yfinance as yf
from yfinance import EquityQuery

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Initial Yahoo screener query (hard filters that Yahoo supports natively)
# ---------------------------------------------------------------------------
def _build_base_query() -> EquityQuery:
    """US equities, price $1–10, market cap < $50M, today's gain > 15%."""
    return EquityQuery(
        "and",
        [
            EquityQuery("eq", ["region", "us"]),
            EquityQuery("btwn", ["intradayprice", 1.0, 10.0]),
            EquityQuery("lt", ["intradaymarketcap", 50_000_000]),
            EquityQuery("gt", ["percentchange", 15.0]),
            EquityQuery("gt", ["dayvolume", 50_000]),  # liquidity floor
        ],
    )


def run_yahoo_screen(size: int = 150) -> list[dict[str, Any]]:
    """
    Run the initial Yahoo Finance equity screen.
    Returns raw quote dicts (max ~250 per Yahoo).
    """
    try:
        q = _build_base_query()
        result = yf.screen(
            q,
            size=size,
            sortField="percentchange",
            sortAsc=False,
        )
        quotes = result.get("quotes", []) if isinstance(result, dict) else []
        logger.info("Yahoo screen returned %d candidates", len(quotes))
        return quotes
    except Exception as e:
        logger.exception("Yahoo screen failed: %s", e)
        return []


# ---------------------------------------------------------------------------
# Deep analysis helpers
# ---------------------------------------------------------------------------
def _safe_float(val: Any, default: float = 0.0) -> float:
    try:
        if val is None or (isinstance(val, float) and np.isnan(val)):
            return default
        return float(val)
    except (TypeError, ValueError):
        return default


def _get_float_shares(info: dict) -> float | None:
    for key in ("floatShares", "sharesFloat", "float"):
        if key in info and info[key]:
            return _safe_float(info[key])
    # fallback approximation
    shares = info.get("sharesOutstanding")
    if shares:
        return _safe_float(shares) * 0.7  # rough estimate
    return None


def _relative_volume(hist: pd.DataFrame, current_vol: float) -> float:
    if hist is None or hist.empty or "Volume" not in hist.columns:
        return 0.0
    # use last 20 trading days average (exclude today if present)
    avg = hist["Volume"].tail(21).iloc[:-1].mean() if len(hist) > 1 else hist["Volume"].mean()
    if avg and avg > 0:
        return current_vol / avg
    return 0.0


def _volume_increasing(hist: pd.DataFrame, min_sessions: int = 2) -> bool:
    """True if volume has risen for at least `min_sessions` consecutive sessions."""
    if hist is None or len(hist) < min_sessions + 1:
        return False
    vols = hist["Volume"].tail(min_sessions + 1).values
    # check last N sessions are strictly increasing
    for i in range(1, len(vols)):
        if vols[i] <= vols[i - 1]:
            return False
    return True


def _above_ma20(hist: pd.DataFrame, price: float) -> bool:
    if hist is None or len(hist) < 20:
        return False
    ma20 = hist["Close"].tail(20).mean()
    return price > ma20


def _has_reverse_split(ticker: yf.Ticker, months: int = 24) -> bool:
    try:
        splits = ticker.splits
        if splits is None or splits.empty:
            return False
        cutoff = datetime.now() - timedelta(days=months * 30)
        recent = splits[splits.index >= pd.Timestamp(cutoff)]
        # reverse split ratio < 1
        return any(r < 1.0 for r in recent.values)
    except Exception:
        return False


def _negative_equity(ticker: yf.Ticker) -> bool:
    try:
        bs = ticker.balance_sheet
        if bs is None or bs.empty:
            return False
        # look for Stockholders Equity / Total Equity
        for label in bs.index:
            low = str(label).lower()
            if "stockholder" in low or "total equity" in low or "shareholder" in low:
                val = bs.loc[label].iloc[0]
                if pd.notna(val) and val < 0:
                    return True
        return False
    except Exception:
        return False


def _parabolic_run_crash(hist: pd.DataFrame, threshold_pct: float = 300.0) -> bool:
    """Detect prior >300% run followed by a significant crash (>50% drawdown)."""
    if hist is None or len(hist) < 60:
        return False
    close = hist["Close"].dropna()
    if len(close) < 60:
        return False
    # rolling max gain over ~3–6 months windows
    for window in (60, 90, 120):
        if len(close) < window:
            continue
        roll_max = close.rolling(window).max()
        roll_min = close.rolling(window).min()
        # look for a high that is >3x a prior low, then subsequent drop >50%
        for i in range(window, len(close)):
            high = roll_max.iloc[i]
            low_before = roll_min.iloc[i - window : i].min()
            if low_before > 0 and (high / low_before - 1) * 100 >= threshold_pct:
                # check if after that high there was a crash
                after = close.iloc[i:]
                if len(after) > 5:
                    peak_idx = after.idxmax()
                    peak_val = after.max()
                    subsequent = after.loc[peak_idx:]
                    if len(subsequent) > 3:
                        trough = subsequent.min()
                        if peak_val > 0 and (1 - trough / peak_val) >= 0.50:
                            return True
    return False


def _positive_news(ticker: yf.Ticker, days: int = 7) -> tuple[bool, list[dict]]:
    """Simple keyword-based positive news check within last N days."""
    positive_kw = {
        "approval", "contract", "award", "partnership", "deal", "surge",
        "breakthrough", "positive", "upgrade", "beat", "raises", "growth",
        "fda", "clearance", "launch", "expansion", "profit", "revenue",
        "buyout", "acquisition", "strategic", "funding", "raise",
    }
    negative_kw = {
        "dilution", "offering", "atm", "shelf", "going concern", "delinquent",
        "warning", "lawsuit", "investigation", "probe", "bankruptcy", "delist",
        "short", "fraud", "sec charge", "restatement",
    }
    try:
        news = ticker.news or []
        cutoff = datetime.now() - timedelta(days=days)
        relevant = []
        has_positive = False
        for item in news[:15]:
            # yfinance news structure varies slightly by version
            content = item.get("content", item)
            title = (
                content.get("title")
                or item.get("title")
                or content.get("headline")
                or ""
            ).lower()
            pub = content.get("pubDate") or item.get("providerPublishTime") or 0
            if isinstance(pub, (int, float)) and pub > 1e12:
                pub = pub / 1000  # ms → s
            try:
                pub_dt = datetime.fromtimestamp(pub) if pub else datetime.now()
            except Exception:
                pub_dt = datetime.now()
            if pub_dt < cutoff:
                continue
            relevant.append({"title": title, "date": pub_dt.isoformat()})
            if any(kw in title for kw in negative_kw):
                continue  # skip clearly negative
            if any(kw in title for kw in positive_kw):
                has_positive = True
        return has_positive, relevant
    except Exception:
        return False, []


def _check_dilution_signals(info: dict, news_titles: list[str]) -> bool:
    """Heuristic: recent ATM / equity offering language or high dilution risk."""
    text = " ".join(news_titles).lower()
    dil_terms = ["atm offering", "at-the-market", "registered direct", "equity offering",
                 "shelf registration", "s-3", "dilutive", "share issuance"]
    return any(t in text for t in dil_terms)


def analyze_ticker(symbol: str, quote: dict | None = None) -> dict[str, Any] | None:
    """
    Full filter + analysis for one ticker.
    Returns a result dict if it passes all criteria, else None.
    """
    try:
        t = yf.Ticker(symbol)
        info = t.info or {}
        if not info:
            return None

        # --- basic fields ---
        price = _safe_float(info.get("regularMarketPrice") or info.get("currentPrice") or quote.get("regularMarketPrice") if quote else 0)
        if not (1.0 <= price <= 10.0):
            return None

        mktcap = _safe_float(info.get("marketCap") or (quote.get("marketCap") if quote else 0))
        if mktcap >= 50_000_000 or mktcap <= 0:
            return None

        float_shares = _get_float_shares(info)
        if float_shares is None or float_shares >= 10_000_000:
            return None

        # history for volume / MA / parabolic
        hist = t.history(period="6mo", auto_adjust=True)
        if hist is None or hist.empty:
            return None

        current_vol = _safe_float(
            info.get("volume") or info.get("regularMarketVolume") or (quote.get("regularMarketVolume") if quote else 0)
        )
        rvol = _relative_volume(hist, current_vol)
        if rvol < 5.0:
            return None

        if not _volume_increasing(hist, min_sessions=2):
            return None

        pct_change = _safe_float(
            info.get("regularMarketChangePercent")
            or (quote.get("regularMarketChangePercent") if quote else None)
            or info.get("percentChange")
        )
        if pct_change < 15.0:
            return None

        if not _above_ma20(hist, price):
            return None

        # --- exclusions ---
        if _has_reverse_split(t, months=24):
            return None
        if _negative_equity(t):
            return None
        if _parabolic_run_crash(hist):
            return None

        has_pos_news, news_items = _positive_news(t, days=7)
        if not has_pos_news:
            return None

        news_titles = [n["title"] for n in news_items]
        if _check_dilution_signals(info, news_titles):
            return None

        # going-concern / delinquent are hard without full 10-K text;
        # we approximate via negative equity + news keywords already covered.

        # --- score for ranking ---
        score = (
            pct_change * 0.35
            + min(rvol, 30) * 1.5
            + (10 if float_shares < 5_000_000 else 5)
            + (5 if mktcap < 25_000_000 else 2)
        )

        return {
            "symbol": symbol,
            "name": info.get("shortName") or info.get("longName") or symbol,
            "price": round(price, 4),
            "pct_change": round(pct_change, 2),
            "market_cap": int(mktcap),
            "float_shares": int(float_shares),
            "volume": int(current_vol),
            "rvol": round(rvol, 2),
            "ma20": round(hist["Close"].tail(20).mean(), 4),
            "sector": info.get("sector") or "N/A",
            "industry": info.get("industry") or "N/A",
            "score": round(score, 2),
            "news": news_items[:5],
            "exchange": info.get("exchange") or "N/A",
        }
    except Exception as e:
        logger.debug("Failed to analyze %s: %s", symbol, e)
        return None


def scan_market(max_candidates: int = 120) -> dict[str, Any]:
    """
    Main entry point: screen → deep filter → rank → return results + top pick.
    """
    raw = run_yahoo_screen(size=max_candidates)
    symbols = []
    quote_map = {}
    for q in raw:
        sym = q.get("symbol")
        if sym and isinstance(sym, str):
            symbols.append(sym)
            quote_map[sym] = q

    results = []
    for sym in symbols:
        res = analyze_ticker(sym, quote_map.get(sym))
        if res:
            results.append(res)

    results.sort(key=lambda x: x["score"], reverse=True)

    top_pick = results[0] if results else None
    analysis = None
    if top_pick:
        analysis = _generate_top_pick_analysis(top_pick)

    return {
        "scanned_at": datetime.utcnow().isoformat() + "Z",
        "candidates_from_yahoo": len(symbols),
        "passed_filters": len(results),
        "results": results,
        "top_pick": top_pick,
        "top_pick_analysis": analysis,
    }


def _generate_top_pick_analysis(pick: dict) -> str:
    """Human-readable rationale for the top pick."""
    lines = [
        f"**{pick['symbol']} – {pick['name']}** is the current top pick.",
        f"- Price: ${pick['price']:.2f} (+{pick['pct_change']:.1f}% today)",
        f"- Market Cap: ${pick['market_cap']:,} | Float: {pick['float_shares']:,} shares",
        f"- Relative Volume: {pick['rvol']:.1f}× average (strong institutional/retail interest)",
        f"- Trading above 20-day MA (${pick['ma20']:.2f})",
        f"- Sector / Industry: {pick['sector']} / {pick['industry']}",
        "",
        "Rationale: The name cleared every hard filter (micro-cap, tight float, "
        "explosive volume expansion, price above MA20, and recent positive catalysts). "
        "No reverse-split, negative-equity, or obvious dilution signals were detected "
        "in the available Yahoo Finance data. Always perform your own due diligence "
        "and check the latest SEC filings (8-K, 10-Q, S-3) before trading.",
    ]
    if pick.get("news"):
        lines.append("\nRecent headlines:")
        for n in pick["news"][:3]:
            lines.append(f"  • {n['title'][:120]}")
    return "\n".join(lines)
