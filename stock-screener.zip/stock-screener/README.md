# U.S. Micro-Cap Momentum Stock Screener

Flask app that screens U.S.-listed stocks via **Yahoo Finance** (`yfinance`) using the following criteria:

### Inclusion
| Filter | Threshold |
|--------|-----------|
| Market Cap | < $50 M |
| Float | < 10 M shares |
| Price | $1 – $10 |
| Relative Volume | > 5× |
| Volume trend | Rising for ≥ 2 consecutive sessions |
| Today’s gain | > 15 % |
| Trend | Price > 20-day moving average |
| Catalyst | Positive news within last 7 days |

### Exclusion
- Reverse splits in the last 24 months  
- Recent ATM / equity-dilution language in headlines  
- Negative shareholder equity  
- Prior parabolic runs (> 300 %) followed by crashes  
- (Heuristic) going-concern / delinquent-filing signals via news + equity

The app ranks survivors by a composite score and highlights a **Top Pick** with a short rationale.

> **Disclaimer**: This is a research / educational tool only. Yahoo Finance data can be delayed or incomplete. Always verify the latest SEC filings (8-K, 10-Q, S-3, etc.) before trading.

---

## Project layout

```
stock-screener/
├── app.py              # Flask entry point
├── screener.py         # Screening + analysis logic
├── templates/
│   └── index.html      # Dashboard UI
├── requirements.txt
├── Procfile            # Railway / Heroku process (Nixpacks fallback)
├── Dockerfile          # Preferred container build for Railway
├── .dockerignore
└── README.md
```

---

## Local development

```bash
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Open http://localhost:5000

- **Run Scan** – uses an 8-minute in-memory cache  
- **Force Refresh** – bypasses cache and re-queries Yahoo

---

## Deploy to Railway.app

Railway will prefer the **Dockerfile** when present (recommended).  
If you remove it, Railway falls back to Nixpacks using `requirements.txt` + `Procfile`.

### Option A – GitHub (recommended)

1. Push this folder to a GitHub repository.
2. Go to [railway.app](https://railway.app) → **New Project** → **Deploy from GitHub repo**.
3. Select the repo. Railway detects the `Dockerfile` and builds the image.
4. `PORT` is injected automatically by Railway — no extra env vars required.
5. Click **Deploy**. After the build finishes, open the public URL.

### Option B – Railway CLI

```bash
npm i -g @railway/cli
railway login
cd stock-screener
railway init
railway up
```

### Local Docker test

```bash
docker build -t stock-screener .
docker run -p 8080:8080 -e PORT=8080 stock-screener
# → http://localhost:8080
```

### Notes for Railway

- Both the `Dockerfile` and `Procfile` run **gunicorn** with a 120 s timeout (scans can take 30–90 s).
- Single worker is intentional – Yahoo rate-limits aggressive multi-worker scraping.
- First request after deploy may be slow while the cold start + screen run.
- Free / hobby plans have sleep / resource limits; consider a paid plan for always-on scanning.

---

## API

| Endpoint | Description |
|----------|-------------|
| `GET /` | Web dashboard |
| `GET /api/scan?force=0&size=100` | JSON results (`force=1` refreshes) |
| `GET /api/health` | Health check |

Example response shape:

```json
{
  "scanned_at": "2026-07-28T...",
  "candidates_from_yahoo": 87,
  "passed_filters": 3,
  "results": [ { "symbol": "XYZ", "price": 4.25, "pct_change": 28.4, ... } ],
  "top_pick": { ... },
  "top_pick_analysis": "..."
}
```

---

## Limitations & future improvements

- Yahoo’s screener returns at most ~250 names per query; the code therefore starts with a high-change / micro-cap slice and then deep-dives.
- Float, balance-sheet equity, and news sentiment are best-effort heuristics; official dilution / going-concern data requires SEC EDGAR or a paid data vendor.
- No authentication or user accounts – suitable for personal / research use.
- Consider adding Redis for multi-instance cache or a background scheduler (APScheduler / Celery) for periodic pre-computation.
